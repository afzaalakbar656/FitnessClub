
********************Admin Credential********************
Username: admin@gmail.com
Password: Test@12345

********************User Credential********************
Username: afzaalakbar0077@gmail.com
Password: Test@12345
or Register a new user